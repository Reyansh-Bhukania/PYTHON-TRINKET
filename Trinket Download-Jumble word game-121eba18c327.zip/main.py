import random
list_of_word=["amazing","define","slender","rattled","dismissed"]

def jumble_word(word):
  word_list=list(word)
  random.shuffle(word_list)
  return "".join(word_list)

def get_hint(word):
  return "The first letter of the word is {}".format(word[0].upper())

def play():
  score=0
  round=4
  print("Welcome to the land where your brain cells will be tested!")
  for i in range(1,round+1):
    word=random.choice(list_of_word)
    scramble_word= jumble_word(word)
    print("\n Round number {}".format(i))
    print("Here is the scrambeled word! Will you be able to get it? {}".format(scramble_word))
    
    hint=input("Do you accept our gift of 1 hint? (yes/no)"). lower()
    if hint=="yes":
      print("Welcome for the hint, Use it wisely....",get_hint(word))
    elif hint=="no":
      print("Ok, Good luck")
    else:
      print("Invalid input")
    
    guess=input("Guess the Word: "). lower()
    while not guess.isalpha():
      print("Write an Alphabet")
      guess=input("Guess the word:"). lower()
     
    if guess==word:
      print("Nice one, I guess you used your brain cells")
      score+=1
    else:
      print("If you did not use the hint, to bad but if you did, Brother like what?")
      print("The correct word was: {}". format(word))
  
  print("\n game over, Final score is :{}/{}". format(score,round))
play()
  
      
  
    